# Dark Music Player 🎵

A dark-themed offline music player built with React Native + Expo.

## Features
- 🎧 Audio playback (MP3/M4A)
- 📂 Playlist management (Add/Rename/Delete/Add Songs)
- 📝 Lyrics screen with `.lrc` file support and auto-sync
- 🌓 Fully dark-themed UI
- 📱 Built using Expo + EAS for APK generation

## Setup

```bash
npm install
npx expo install
eas build --platform android
```

## Screens
- Home
- Now Playing
- Playlist
- Lyrics
- Settings (optional)
